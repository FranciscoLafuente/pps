import os
import sys
from pathlib import Path

import pytest

VERSION = os.environ.get("VERSION", "v2")          # v1 = vulnerable, v2 = corregida
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "app" / VERSION))


@pytest.fixture
def bd():
    from datos import crear_bd
    conn = crear_bd()
    yield conn
    conn.close()
