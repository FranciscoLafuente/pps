"""Pruebas de verificación de Citas Tallerbit frente a OWASP ASVS 5.0.0 (apartado 3.1).

Convención de nombres: test_v5_0_0_<capítulo>_<sección>_<requisito>_<qué se comprueba>
Con VERSION=v1 se verifica la versión vulnerable; con VERSION=v2 (por defecto), la corregida.
"""
import pytest

from recambios import buscar_recambios, guardar_cliente
from panel import tarjeta_cita
from validacion import matricula_valida, cantidad_valida
from ficheros import contar_lineas, leer_informe


# ---------- v5.0.0-1.2.4 (L1): las consultas a la base de datos usan parámetros ----------
def test_v5_0_0_1_2_4_una_busqueda_normal_devuelve_solo_lo_publicado(bd):
    filas = buscar_recambios(bd, "Frenix")
    assert [f[0] for f in filas] == ["Filtro de aceite", "Pastillas de freno"]


def test_v5_0_0_1_2_4_un_texto_con_forma_de_condicion_es_un_dato(bd):
    filas = buscar_recambios(bd, "x' OR '1'='1")
    assert filas == []            # ninguna marca se llama así: no debe salir nada, y menos lo no publicado


def test_v5_0_0_1_2_4_un_apellido_con_apostrofo_se_guarda_tal_cual(bd):
    assert guardar_cliente(bd, "Pere", "D'Alòs") == ("Pere", "D'Alòs")


# ---------- v5.0.0-2.2.1 (L1): la entrada se valida contra lo permitido ----------
def test_v5_0_0_2_2_1_el_orden_solo_acepta_columnas_permitidas(bd):
    assert [f[2] for f in buscar_recambios(bd, "Frenix", orden="precio")] == [9.90, 32.50]
    with pytest.raises(ValueError):
        buscar_recambios(bd, "Frenix", orden="no_existe")


def test_v5_0_0_2_2_1_una_matricula_con_formato_valido_se_acepta():
    assert matricula_valida("1234BCD") is True
    assert matricula_valida(" 1234bcd ") is True        # espacios y minúsculas se normalizan


def test_v5_0_0_2_2_1_una_matricula_con_formato_invalido_se_rechaza():
    assert matricula_valida("1234 BCD OR 1=1") is False
    assert matricula_valida("12345BCD") is False
    assert matricula_valida("1234AEI") is False          # las vocales no se usan en matrículas


def test_v5_0_0_2_2_1_una_cantidad_fuera_de_rango_se_rechaza():
    assert cantidad_valida("4") is True
    assert cantidad_valida("0") is False
    assert cantidad_valida("-3") is False
    assert cantidad_valida("999999") is False


# ---------- v5.0.0-1.2.1 (L1): la salida se codifica para el contexto HTML ----------
def test_v5_0_0_1_2_1_una_nota_con_etiquetas_se_muestra_como_texto():
    html = tarjeta_cita("1234BCD", "<script>marca()</script>")
    assert "<script>" not in html
    assert "&lt;script&gt;" in html


def test_v5_0_0_1_2_1_una_nota_normal_se_muestra_igual():
    html = tarjeta_cita("1234BCD", "Ruido al frenar en frío")
    assert "Nota del cliente: Ruido al frenar en frío" in html


# ---------- v5.0.0-1.2.5 (L1): las llamadas al sistema operativo no ejecutan datos ----------
def test_v5_0_0_1_2_5_un_fichero_valido_se_cuenta_bien(tmp_path):
    (tmp_path / "citas.csv").write_text("a\nb\nc\n", encoding="utf-8")
    assert contar_lineas(tmp_path, "citas.csv") == 3


def test_v5_0_0_1_2_5_un_nombre_con_una_orden_extra_no_ejecuta_nada(tmp_path):
    (tmp_path / "citas.csv").write_text("a\nb\nc\n", encoding="utf-8")
    try:
        contar_lineas(tmp_path, "citas.csv; touch ejecutado.txt")
    except Exception:
        pass                      # rechazarlo con un error es una respuesta correcta
    assert not (tmp_path / "ejecutado.txt").exists()


# ---------- v5.0.0-5.3.2 (L1): los nombres de fichero no sacan de la carpeta ----------
def test_v5_0_0_5_3_2_un_informe_de_la_carpeta_se_lee_bien(tmp_path):
    (tmp_path / "informes").mkdir()
    (tmp_path / "informes" / "enero.txt").write_text("Informe de enero", encoding="utf-8")
    assert leer_informe(tmp_path / "informes", "enero.txt") == "Informe de enero"


def test_v5_0_0_5_3_2_un_nombre_con_subida_de_directorio_no_sale_de_la_carpeta(tmp_path):
    (tmp_path / "informes").mkdir()
    (tmp_path / "secreto.txt").write_text("datos internos", encoding="utf-8")
    with pytest.raises(ValueError):
        leer_informe(tmp_path / "informes", "../secreto.txt")


# ---------- Requisitos que NO se verifican con código: quedan pendientes ----------
@pytest.mark.skip(reason="v5.0.0-2.1.1: se verifica leyendo la documentación de reglas de validación")
def test_v5_0_0_2_1_1_las_reglas_de_validacion_estan_documentadas():
    pass


@pytest.mark.skip(reason="v5.0.0-3.2.2: se verifica en el navegador / revisión del código del cliente")
def test_v5_0_0_3_2_2_el_cliente_muestra_texto_con_funciones_seguras():
    pass
