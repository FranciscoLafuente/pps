#!/usr/bin/env bash
# Ensayo de la demostración de 3.1. Uso: bash ensayo.sh   (con el entorno de pytest activado)
#   source /opt/pps/venv/bin/activate
set -u
cd "$(dirname "$0")"
echo "=== pytest: $(pytest --version) · Python: $(python3 --version)"
for v in v1 v2; do
  echo
  echo "=============== Versión $v ==============="
  VERSION=$v pytest -v -rs 2>&1 | sed 's#verificacion/test_asvs.py::##' | grep -E "PASSED|FAILED|SKIPPED|passed|failed"
done
echo
echo "Esperado: v1 -> 8 failed, 5 passed, 2 skipped · v2 -> 13 passed, 2 skipped"
