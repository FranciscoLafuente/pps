# ficheros.py - VERSIÓN CORREGIDA
import re
import subprocess
from pathlib import Path

NOMBRE_CSV = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,39}\.csv")      # lista blanca de nombres de exportación


def contar_lineas(carpeta, nombre):
    """Cuenta las líneas de un fichero CSV de la carpeta de exportaciones."""
    if NOMBRE_CSV.fullmatch(nombre) is None:
        raise ValueError("Nombre de fichero no permitido")
    # Lista de argumentos y sin shell: el nombre es un dato, nunca parte de la orden
    salida = subprocess.run(["wc", "-l", nombre], cwd=carpeta, capture_output=True, text=True)
    return int(salida.stdout.split()[0])


def leer_informe(carpeta, nombre):
    """Devuelve el contenido de un informe de la carpeta de informes."""
    base = Path(carpeta).resolve()
    ruta = (base / nombre).resolve()                      # resuelve '..' y enlaces antes de comprobar
    if not ruta.is_relative_to(base):
        raise ValueError("Ruta fuera de la carpeta de informes")
    return ruta.read_text(encoding="utf-8")
