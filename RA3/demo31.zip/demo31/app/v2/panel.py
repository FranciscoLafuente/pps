# panel.py - VERSIÓN CORREGIDA
from html import escape


def tarjeta_cita(matricula, nota_cliente):
    """HTML de una cita en el panel del mecánico. 'nota_cliente' la escribe el cliente al pedir la cita."""
    return (
        '<div class="cita">'
        f"<h3>{escape(matricula)}</h3>"
        f"<p>Nota del cliente: {escape(nota_cliente)}</p>"   # codificación de salida para contexto HTML
        "</div>"
    )
