# recambios.py - VERSIÓN CORREGIDA
ORDENES_PERMITIDOS = {"nombre": "nombre", "precio": "precio"}


def buscar_recambios(conn, marca, orden="nombre"):
    """Devuelve los recambios PUBLICADOS de una marca, ordenados por la columna indicada."""
    if orden not in ORDENES_PERMITIDOS:
        raise ValueError("Criterio de ordenación no permitido")
    columna = ORDENES_PERMITIDOS[orden]          # el valor sale de NUESTRO diccionario, no del usuario
    sql = (
        "SELECT nombre, marca, precio FROM recambios "
        f"WHERE publicado = 1 AND marca = ? ORDER BY {columna}"
    )
    return conn.execute(sql, (marca,)).fetchall()   # el dato viaja por separado de la orden


def guardar_cliente(conn, nombre, apellido):
    """Da de alta a un cliente."""
    conn.execute("INSERT INTO clientes (nombre, apellido) VALUES (?, ?)", (nombre, apellido))
    conn.commit()
    return conn.execute("SELECT nombre, apellido FROM clientes ORDER BY id DESC LIMIT 1").fetchone()
