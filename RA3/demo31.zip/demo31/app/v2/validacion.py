# validacion.py - VERSIÓN CORREGIDA
import re
import unicodedata

PATRON_MATRICULA = re.compile(r"[0-9]{4}[BCDFGHJKLMNPRSTVWXYZ]{3}")   # lista blanca: formato actual español
CANTIDAD_MINIMA, CANTIDAD_MAXIMA = 1, 20


def matricula_valida(texto):
    """Lista blanca: solo se acepta lo que cumple el formato esperado."""
    if not isinstance(texto, str):
        return False
    normalizado = unicodedata.normalize("NFKC", texto).strip().upper()   # forma canónica ANTES de validar
    return PATRON_MATRICULA.fullmatch(normalizado) is not None


def cantidad_valida(texto):
    """Entero entre 1 y 20 (tipo, rango y formato)."""
    if not isinstance(texto, str) or not re.fullmatch(r"[0-9]{1,3}", texto.strip()):
        return False
    return CANTIDAD_MINIMA <= int(texto) <= CANTIDAD_MAXIMA
