"""Base de datos de ejemplo de Citas Tallerbit (SQLite en memoria, datos inventados)."""
import sqlite3


def crear_bd():
    conn = sqlite3.connect(":memory:")
    conn.executescript(
        """
        CREATE TABLE recambios (id INTEGER PRIMARY KEY, nombre TEXT, marca TEXT,
                                precio REAL, publicado INTEGER);
        CREATE TABLE clientes (id INTEGER PRIMARY KEY, nombre TEXT, apellido TEXT);
        """
    )
    conn.executemany(
        "INSERT INTO recambios (nombre, marca, precio, publicado) VALUES (?, ?, ?, ?)",
        [
            ("Pastillas de freno", "Frenix", 32.50, 1),
            ("Filtro de aceite", "Frenix", 9.90, 1),
            ("Bujía", "Chispa", 6.40, 1),
            ("Kit de distribución (sin salida)", "Chispa", 120.00, 0),
            ("Disco de freno (pendiente de precio)", "Frenix", 55.00, 0),
        ],
    )
    conn.commit()
    return conn
