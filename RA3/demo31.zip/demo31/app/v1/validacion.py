# validacion.py - VERSIÓN VULNERABLE (solo para el laboratorio)
CARACTERES_PROHIBIDOS = ["'", '"', ";", "--", "<", ">"]


def matricula_valida(texto):
    """Lista negra: rechaza lo que 'parece peligroso' y acepta todo lo demás."""
    return not any(c in texto for c in CARACTERES_PROHIBIDOS)


def cantidad_valida(texto):
    """Comprueba solo que sea un número."""
    try:
        int(texto)
        return True
    except ValueError:
        return False
