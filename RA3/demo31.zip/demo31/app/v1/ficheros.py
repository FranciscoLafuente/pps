# ficheros.py - VERSIÓN VULNERABLE (solo para el laboratorio)
import os
import subprocess


def contar_lineas(carpeta, nombre):
    """Cuenta las líneas de un fichero CSV de la carpeta de exportaciones."""
    orden = f"wc -l {nombre}"
    salida = subprocess.run(orden, shell=True, cwd=carpeta, capture_output=True, text=True)
    return int(salida.stdout.split()[0])


def leer_informe(carpeta, nombre):
    """Devuelve el contenido de un informe de la carpeta de informes."""
    with open(os.path.join(carpeta, nombre), encoding="utf-8") as f:
        return f.read()
