# recambios.py - VERSIÓN VULNERABLE (solo para el laboratorio)
def buscar_recambios(conn, marca, orden="nombre"):
    """Devuelve los recambios PUBLICADOS de una marca, ordenados por la columna indicada."""
    sql = (
        "SELECT nombre, marca, precio FROM recambios "
        f"WHERE publicado = 1 AND marca = '{marca}' ORDER BY {orden}"
    )
    return conn.execute(sql).fetchall()


def guardar_cliente(conn, nombre, apellido):
    """Da de alta a un cliente."""
    conn.execute(
        f"INSERT INTO clientes (nombre, apellido) VALUES ('{nombre}', '{apellido}')"
    )
    conn.commit()
    return conn.execute("SELECT nombre, apellido FROM clientes ORDER BY id DESC LIMIT 1").fetchone()
