# panel.py - VERSIÓN VULNERABLE (solo para el laboratorio)
def tarjeta_cita(matricula, nota_cliente):
    """HTML de una cita en el panel del mecánico. 'nota_cliente' la escribe el cliente al pedir la cita."""
    return (
        '<div class="cita">'
        f"<h3>{matricula}</h3>"
        f"<p>Nota del cliente: {nota_cliente}</p>"
        "</div>"
    )
