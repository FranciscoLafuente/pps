"""Comprobación opcional del lado cliente (v5.0.0-3.2.2) con un navegador automatizado.
Requiere: pip install playwright && playwright install chromium   (solo para el profesor)
Uso: python3 comprobar_cliente.py
Prueba con una nota inofensiva que contiene una etiqueta de imagen rota con un manejador de error
que solo escribe una marca en la propia página: no sale nada de la máquina."""
from pathlib import Path
from playwright.sync_api import sync_playwright

NOTA = '<img src="no-existe.png" onerror="window.__marca=1">'
base = Path(__file__).resolve().parent / "cliente"

with sync_playwright() as p:
    nav = p.chromium.launch()
    for version in ("v1", "v2"):
        pagina = nav.new_page()
        pagina.goto((base / f"panel_{version}.html").as_uri())
        pagina.fill("#nota", NOTA)
        pagina.click("#mostrar")
        pagina.wait_for_timeout(300)
        ejecutado = pagina.evaluate("window.__marca === 1")
        texto = pagina.inner_text("#salida")
        print(f"{version}: manejador ejecutado = {ejecutado}; texto visible = {texto!r}")
    nav.close()
